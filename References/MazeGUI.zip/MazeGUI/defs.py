


boards = {}


DOWN = 0
RIGHT = 1
UP = 2
LEFT = 3

SOUTH = 0
EAST = 1
NORTH = 2
WEST = 3